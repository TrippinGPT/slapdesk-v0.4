/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { BeatConfig, BeatData, ReferenceDNA, TrackType } from './types';
import { createDefaultConfig, generateFullBeat } from './engine/generator';
import { audioEngine } from './engine/audioEngine';
import { generateMidiFile } from './engine/midiWriter';
import { exportProjectZip } from './engine/zipExporter';
import { beatToTokens } from './engine/tokenCodec';
import { CURATED_REFERENCE_TARGETS } from './engine/referenceLibrary';

import { CookupControls } from './components/CookupControls';
import { PatternGrid } from './components/PatternGrid';
import { StudioKitModal } from './components/StudioKitModal';
import { ReferenceModeModal } from './components/ReferenceModeModal';
import { TestLabModal } from './components/TestLabModal';
import { TokenLabModal } from './components/TokenLabModal';
import { CodeViewerModal } from './components/CodeViewerModal';

import {
  Download,
  FileArchive,
  Disc3,
  Sparkles,
  ShieldCheck,
  Cpu,
  Flame,
  Check,
  Music2,
  Copy,
  Info,
  FileCode,
  Youtube,
  ExternalLink,
} from 'lucide-react';

export default function App() {
  // App state
  const [config, setConfig] = useState<BeatConfig>(() => createDefaultConfig());
  const [beatData, setBeatData] = useState<BeatData>(() => generateFullBeat(config));
  const [referenceDNA, setReferenceDNA] = useState<ReferenceDNA | undefined>();

  // Playback state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [currentBar, setCurrentBar] = useState(0);

  // Modals
  const [showStudioKit, setShowStudioKit] = useState(false);
  const [showReferenceMode, setShowReferenceMode] = useState(false);
  const [showTestLab, setShowTestLab] = useState(false);
  const [showTokenLab, setShowTokenLab] = useState(false);
  const [showCodeViewer, setShowCodeViewer] = useState(false);

  // Notifications
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const toastTimeoutRef = useRef<number | null>(null);

  const showToast = (msg: string) => {
    if (toastTimeoutRef.current) window.clearTimeout(toastTimeoutRef.current);
    setToastMsg(msg);
    toastTimeoutRef.current = window.setTimeout(() => setToastMsg(null), 3500);
  };

  // Wire Web Audio callbacks
  useEffect(() => {
    audioEngine.setCallbacks(
      (step, bar) => {
        setCurrentStep(step);
        setCurrentBar(bar);
      },
      playing => {
        setIsPlaying(playing);
      }
    );

    return () => {
      audioEngine.stop();
    };
  }, []);

  // Update audio engine's beat data when it changes
  useEffect(() => {
    audioEngine.setBeatData(beatData);
  }, [beatData]);

  // Keyboard shortcut: Space to play/pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if typing in an input
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        return;
      }
      if (e.code === 'Space') {
        e.preventDefault();
        handlePlayToggle();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, beatData]);

  const handlePlayToggle = () => {
    if (isPlaying) {
      audioEngine.pause();
    } else {
      audioEngine.play(beatData, currentStep);
    }
  };

  const handleStop = () => {
    audioEngine.stop();
    setCurrentStep(0);
    setCurrentBar(0);
  };

  // 1. New Cookup (rolls new seed, generates new beat)
  const handleNewCookup = () => {
    const newSeed = Math.floor(Math.random() * 900000 + 100000);
    const newConfig: BeatConfig = {
      ...config,
      seed: newSeed,
      variation: 'V1',
      // Optionally pick a fresh kick pocket family
      kickFamilyId: Math.floor(Math.random() * 40) + 1,
      bassFamilyId: Math.floor(Math.random() * 10) + 1,
      phraseFamilyId: Math.floor(Math.random() * 10) + 1,
      hatFamilyId: Math.floor(Math.random() * 18) + 1,
    };
    const newBeat = generateFullBeat(newConfig, referenceDNA);
    setConfig(newConfig);
    setBeatData(newBeat);
    showToast(`Cooked new beat (Seed #${newSeed})`);
  };

  // 2. Random Seed
  const handleRandomSeed = () => {
    const newSeed = Math.floor(Math.random() * 900000 + 100000);
    const newConfig = { ...config, seed: newSeed };
    const newBeat = generateFullBeat(newConfig, referenceDNA);
    setConfig(newConfig);
    setBeatData(newBeat);
    showToast(`Seed updated: #${newSeed}`);
  };

  // 3. Variation Change (V1, V2, V3 siblings)
  const handleVariationChange = (variation: 'V1' | 'V2' | 'V3') => {
    if (config.variation === variation) return;
    const newConfig = { ...config, variation };
    const newBeat = generateFullBeat(newConfig, referenceDNA);
    setConfig(newConfig);
    setBeatData(newBeat);
    showToast(`Switched to sibling variation ${variation}`);
  };

  // 4. Targeted Recook (Drums, 808, or Music) with intelligent intent support
  const handleRecook = (target: 'drums' | '808' | 'music', intent?: any) => {
    const recookConfig = intent ? { ...config, recookIntent: intent } : config;
    const newBeat = generateFullBeat(recookConfig, referenceDNA, target, beatData.tracks);
    setBeatData(newBeat);
    const label = target === 'drums' ? 'Drums (Kick/Snare/Hats)' : target === '808' ? '808 Bass' : `Music (${intent || 'New Idea'})`;
    showToast(`Recooked ${label} isolated`);
  };

  // 5. Config Change (sliders, BPM, Key, Families)
  const handleConfigChange = (updates: Partial<BeatConfig>) => {
    const newConfig = { ...config, ...updates };
    const newBeat = generateFullBeat(newConfig, referenceDNA);
    setConfig(newConfig);
    setBeatData(newBeat);
  };

  // 6. Track Mute / Solo
  const handleToggleMute = (trackId: TrackType) => {
    setBeatData(prev => {
      const updatedTracks = {
        ...prev.tracks,
        [trackId]: {
          ...prev.tracks[trackId],
          muted: !prev.tracks[trackId].muted,
        },
      };
      return { ...prev, tracks: updatedTracks };
    });
  };

  const handleToggleSolo = (trackId: TrackType) => {
    setBeatData(prev => {
      const updatedTracks = {
        ...prev.tracks,
        [trackId]: {
          ...prev.tracks[trackId],
          solo: !prev.tracks[trackId].solo,
        },
      };
      return { ...prev, tracks: updatedTracks };
    });
  };

  // 7. Reference DNA Apply
  const handleApplyDNA = (dna: ReferenceDNA, lockConstraints: boolean) => {
    setReferenceDNA(dna);
    if (lockConstraints) {
      const newConfig: BeatConfig = {
        ...config,
        bpm: dna.detectedBpm || config.bpm,
        density: dna.kickDensity,
        darkness: dna.darkness,
        vocalSpace: dna.vocalSpace,
        bassMovement: dna.bass808Activity,
        kickFamilyId: dna.recommendedKickFamilyId !== undefined ? dna.recommendedKickFamilyId : config.kickFamilyId,
        hatFamilyId: dna.recommendedHatFamilyId !== undefined ? dna.recommendedHatFamilyId : config.hatFamilyId,
        bassFamilyId: dna.recommendedBassFamilyId !== undefined ? dna.recommendedBassFamilyId : config.bassFamilyId,
        melodyPersonalityId: dna.recommendedMelodyPersonalityId || config.melodyPersonalityId,
        swing: dna.swing !== undefined ? dna.swing : config.swing,
        rootKey: dna.recommendedKey || config.rootKey,
        scale: dna.recommendedScale || config.scale,
      };
      const newBeat = generateFullBeat(newConfig, dna);
      setConfig(newConfig);
      setBeatData(newBeat);
    }
    showToast(`Reference Target applied: ${dna.title || dna.sourceFileName}`);
  };

  const handleClearDNA = () => {
    setReferenceDNA(undefined);
    showToast('Reference DNA cleared');
  };

  // 8. Download MIDI
  const handleDownloadMidi = () => {
    try {
      const bytes = generateMidiFile(beatData);
      const blob = new Blob([bytes], { type: 'audio/midi' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `SlapDesk_${config.rootKey}_${config.bpm}BPM_${config.variation}_Seed${config.seed}.mid`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Downloaded multi-track Type 1 MIDI (.mid)');
    } catch (e: any) {
      alert(`MIDI export error: ${e.message}`);
    }
  };

  // 9. Download Project ZIP
  const handleDownloadZip = async () => {
    try {
      showToast('Packaging stems, MIDI & LLM tokens...');
      const zipBlob = await exportProjectZip(beatData);
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `SlapDesk_Session_Seed${config.seed}_${config.rootKey}_${config.bpm}BPM.zip`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Project ZIP downloaded with individual stems!');
    } catch (e: any) {
      alert(`ZIP packaging error: ${e.message}`);
    }
  };

  // 10. Copy Tokens Quick Action
  const handleCopyTokens = () => {
    const tokens = beatToTokens(beatData);
    navigator.clipboard.writeText(tokens);
    showToast('Beat tokens copied to clipboard');
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col selection:bg-amber-500 selection:text-zinc-950 font-sans">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 bg-amber-500 text-zinc-950 font-bold text-xs rounded-lg shadow-2xl animate-fade-in border border-amber-300">
          <Check className="w-4 h-4" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Top Brand Header */}
      <header className="border-b border-zinc-800/80 bg-zinc-900/90 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500 flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Flame className="w-5 h-5 text-zinc-950 fill-zinc-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-tight text-white">
                  SlapDesk <span className="text-amber-500">v0.4</span>
                </h1>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-zinc-800 text-zinc-300 border border-zinc-700 rounded">
                  8-Bar Phrase Memory
                </span>
                <span className="hidden md:inline-block px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-zinc-800 text-amber-400 border border-zinc-700 rounded">
                  40 Kick Families
                </span>
              </div>
              <p className="text-[11px] text-zinc-400">
                West Coast & Detroit Slap Music Generator • Algorithmic Local LLM Engine
              </p>
            </div>
          </div>

          {/* Action Modals Toolbar */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setShowStudioKit(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold rounded-lg border border-zinc-700 transition"
              title="Studio Kit Custom Drum Samples"
            >
              <Disc3 className="w-3.5 h-3.5 text-amber-400" />
              <span>Studio Kit</span>
            </button>

            <button
              onClick={() => setShowReferenceMode(true)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition ${
                referenceDNA
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border-zinc-700'
              }`}
              title="Reference Audio DNA Analysis"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Reference DNA {referenceDNA ? '✓' : ''}</span>
            </button>

            <button
              onClick={() => setShowTestLab(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold rounded-lg border border-zinc-700 transition"
              title="Automated Test Suite (100 Cookups)"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Test Lab</span>
            </button>

            <button
              onClick={() => setShowTokenLab(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold rounded-lg border border-zinc-700 transition"
              title="Ollama LLM Text Tokens & Training"
            >
              <Cpu className="w-3.5 h-3.5 text-amber-400" />
              <span>Token Lab</span>
            </button>

            <button
              onClick={() => setShowCodeViewer(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold rounded-lg border border-zinc-700 transition"
              title="Browse Source Code"
            >
              <FileCode className="w-3.5 h-3.5 text-cyan-400" />
              <span>View Code</span>
            </button>

            <a
              href="/slapdesk_v0.4_source_code.zip"
              download="slapdesk_v0.4_source_code.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold rounded-lg border border-amber-500/40 transition"
              title="Download Complete Project Source Code ZIP"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Source ZIP</span>
            </a>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 space-y-4">
        {/* Reference Target Quick-Select Bar */}
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-3 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Youtube className="w-3.5 h-3.5 text-red-500" />
              <span>Reference Target Library:</span>
            </span>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            {CURATED_REFERENCE_TARGETS.map(target => {
              const isActive = referenceDNA?.id === target.id;
              return (
                <button
                  key={target.id}
                  onClick={() => handleApplyDNA(target, true)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-amber-500 text-zinc-950 border-amber-400 shadow-md font-bold'
                      : 'bg-zinc-950/70 hover:bg-zinc-800 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                  }`}
                  title={`${target.title} (${target.author})`}
                >
                  <span>{target.title.split(' ')[0]} {target.title.includes('Cardo') ? 'Cardo' : target.title.includes('Southside') ? 'Southside' : target.title.includes('Wheezy') ? 'Wheezy' : target.title.includes('Vezzo') ? 'Vezzo' : 'Roadrunner'}</span>
                  <span className="text-[10px] opacity-75 font-mono">{target.detectedBpm}</span>
                  {isActive && <Check className="w-3 h-3 stroke-[3]" />}
                </button>
              );
            })}

            <button
              onClick={() => setShowReferenceMode(true)}
              className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 text-amber-300 border border-amber-500/30 transition flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3" />
              <span>More & Custom...</span>
            </button>
          </div>
        </div>

        {/* Reference Mode Active Banner */}
        {referenceDNA && (
          <div className="p-3.5 bg-gradient-to-r from-amber-950/40 via-zinc-900 to-zinc-900 border border-amber-500/40 rounded-xl text-xs space-y-1.5 shadow-md">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2 text-amber-300">
                <Sparkles className="w-4 h-4 shrink-0 text-amber-400" />
                <span className="font-bold text-sm text-zinc-100">
                  {referenceDNA.title || referenceDNA.sourceFileName}
                </span>
                {referenceDNA.author && (
                  <span className="text-[11px] text-zinc-400">
                    via <strong className="text-zinc-300">{referenceDNA.author}</strong>
                  </span>
                )}
                {referenceDNA.category && (
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold uppercase tracking-wider">
                    {referenceDNA.category}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3">
                {referenceDNA.youtubeUrl && (
                  <a
                    href={referenceDNA.youtubeUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-red-400 hover:text-red-300 underline text-xs font-medium"
                  >
                    <Youtube className="w-3.5 h-3.5" />
                    <span>Watch Tutorial</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                <button
                  onClick={handleClearDNA}
                  className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded text-[11px] font-medium border border-zinc-700 transition"
                >
                  Unlock Reference
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4 text-zinc-300 text-[11px] flex-wrap pt-1 border-t border-zinc-800/80">
              <span>BPM: <strong className="text-amber-400 font-mono">{referenceDNA.detectedBpm}</strong></span>
              <span>Kick Density: <strong className="text-zinc-100 font-mono">{referenceDNA.kickDensity}%</strong></span>
              <span>Vocal Headroom: <strong className="text-amber-300 font-mono">{referenceDNA.vocalSpace}%</strong></span>
              <span>808 Activity: <strong className="text-zinc-100 font-mono">{referenceDNA.bass808Activity}%</strong></span>
              <span>Darkness: <strong className="text-zinc-100 font-mono">{referenceDNA.darkness}%</strong></span>
              {referenceDNA.swing !== undefined && (
                <span>Swing: <strong className="text-amber-400 font-mono">{referenceDNA.swing}%</strong></span>
              )}
            </div>

            {referenceDNA.producerTips && (
              <p className="text-[11px] text-zinc-400 italic pt-0.5">
                💡 {referenceDNA.producerTips}
              </p>
            )}
          </div>
        )}

        {/* Cookup Controls (New Cookup, Sliders, Sibling V1/V2/V3, Recook, Families) */}
        <CookupControls
          config={config}
          isPlaying={isPlaying}
          melodyQuality={beatData.melodyQuality}
          melodyPersonalityName={beatData.melodyPersonalityName}
          melodyMotifName={beatData.melodyMotifName}
          onPlayToggle={handlePlayToggle}
          onStop={handleStop}
          onNewCookup={handleNewCookup}
          onRecook={handleRecook}
          onVariationChange={handleVariationChange}
          onConfigChange={handleConfigChange}
          onRandomSeed={handleRandomSeed}
        />

        {/* 8-Bar Pattern Grid & Visualizer */}
        <PatternGrid
          beatData={beatData}
          currentStep={currentStep}
          currentBar={currentBar}
          isPlaying={isPlaying}
          onToggleMute={handleToggleMute}
          onToggleSolo={handleToggleSolo}
        />

        {/* Export & Production Action Bar */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 shadow-xl flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-zinc-400">
            <Music2 className="w-4 h-4 text-amber-400" />
            <span>
              Session: <strong className="text-zinc-200">{config.rootKey} {config.scale.replace('_', ' ')}</strong> at <strong className="text-zinc-200">{config.bpm} BPM</strong> ({config.variation})
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleCopyTokens}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold rounded-lg transition border border-zinc-700 cursor-pointer"
              title="Copy Space-Separated LLM Beat Tokens"
            >
              <Copy className="w-3.5 h-3.5" />
              Copy Tokens
            </button>

            <button
              onClick={handleDownloadMidi}
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 active:scale-98 text-zinc-950 text-xs font-black rounded-lg shadow transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Download MIDI (.mid)
            </button>

            <button
              onClick={handleDownloadZip}
              className="flex items-center gap-1.5 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 active:scale-98 text-zinc-100 text-xs font-bold rounded-lg border border-zinc-700 transition cursor-pointer"
            >
              <FileArchive className="w-4 h-4 text-amber-400" />
              Beat Session ZIP
            </button>

            <a
              href="/slapdesk_v0.4_source_code.zip"
              download="slapdesk_v0.4_source_code.zip"
              className="flex items-center gap-1.5 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 active:scale-98 text-amber-300 text-xs font-bold rounded-lg border border-amber-500/40 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Source Code ZIP
            </a>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-900 py-4 px-6 text-center text-[11px] text-zinc-600">
        SlapDesk v0.4 • 8-Bar Phrase Memory • General MIDI Standard (Ch 0: Melody, Ch 1: Keys, Ch 2: 808 Bass, Ch 9: Drums) • 480 PPQ
      </footer>

      {/* Modals */}
      <StudioKitModal
        isOpen={showStudioKit}
        onClose={() => setShowStudioKit(false)}
      />

      <ReferenceModeModal
        isOpen={showReferenceMode}
        onClose={() => setShowReferenceMode(false)}
        currentDNA={referenceDNA}
        onApplyDNA={handleApplyDNA}
        onClearDNA={handleClearDNA}
      />

      <TestLabModal
        isOpen={showTestLab}
        onClose={() => setShowTestLab(false)}
      />

      <TokenLabModal
        isOpen={showTokenLab}
        onClose={() => setShowTokenLab(false)}
        beatData={beatData}
      />

      <CodeViewerModal
        isOpen={showCodeViewer}
        onClose={() => setShowCodeViewer(false)}
      />
    </div>
  );
}
